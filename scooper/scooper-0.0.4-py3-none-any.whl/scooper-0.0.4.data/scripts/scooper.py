#!python

"""
scooper.py by William Grover - wgrover@gmail.com
"""

import warnings
warnings.filterwarnings("ignore", "(?s).*MATPLOTLIBDATA.*",
                        category=UserWarning)

import matplotlib.cbook
warnings.filterwarnings("ignore",
                        category=matplotlib.cbook.mplDeprecation)

import matplotlib.pyplot as plt
import numpy as np
import scipy.stats
import sys
import os

class run:
    def __init__(self, filename):
        self.filename = filename
        self.f = open(self.filename, "r")
        start_time = 0
        self.time = []
        self.action_time = []
        self.action = []
        self.experiment_starts = []
        self.experiment_ends = []
        self.experiments = []
        self.pressure_sensor_1 = []
        self.pressure_sensor_2 = []
        self.bubble_sensor_1 = []
        self.bubble_sensor_2 = []
        self.bubble_sensor_3 = []
        self.bubble_sensor_4 = []
        self.bubble_sensor_5 = []
        self.bubble_sensor_6 = []
        self.bag_scale_sample = []
        self.bag_scale_dilution = []
        self.bag_scale_buffer = []
        self.bag_scale_detergent = []
        self.bag_scale_product = []
        self.bag_scale_waste_1 = []
        self.bag_scale_waste_2 = []
        self.door_sensor = []
        self.cassette_sensor = []
        self.degasser = []
        self.emergency_stop = []
        self.valve_1 = []
        self.valve_2 = []
        self.valve_3 = []
        self.valve_4 = []
        self.valve_5 = []
        self.valve_6 = []
        self.valve_7 = []
        self.valve_8 = []
        self.valve_9 = []
        self.valve_10 = []
        self.valve_11 = []
        self.valve_12 = []
        self.valve_13 = []
        self.valve_14 = []
        self.pump_1 = []
        self.pump_2 = []
        self.pump_3 = []
        self.pump_4 = []
        self.in_experiment = False

        for line in self.f.readlines():
            if(line.split(",")[0].isnumeric()):  # only process lines that start with timestamp
                if start_time == 0:
                    start_time = int(line.split(",")[0])
                if line.count(",") == 1:  # if this line has only an action
                    if self.in_experiment:  # this is temporary; replace with experiment end
                        self.experiment_ends.append((int(line.split(",")[0]) - start_time) / 1000.0 / 60.0)
                        self.in_experiment = False
                    self.action_time.append((int(line.split(",")[0]) - start_time) / 1000.0 / 60.0)
                    self.action.append(line.split(",")[1].strip())
                    if "Waiting" in line.split(",")[1].strip():  # if this is the start of an experiment
                        self.experiment_starts.append((int(line.split(",")[0]) - start_time) / 1000.0 / 60.0)
                        self.experiments.append("Waiting")  # this is temporary; replace with experiment name
                        self.in_experiment = True

                if line.count(",") > 1:  # if this line also has measurements
                    l = line.split(",")
                    if len(l) == 40:  # this ignores lines with User Prompts
                        self.time.append((int(l[0]) - start_time) / 1000.0 / 60.0)
                        self.pressure_sensor_1.append(float(l[2]))
                        self.pressure_sensor_2.append(float(l[3]))
                        self.bubble_sensor_1.append(float(l[4]))
                        self.bubble_sensor_2.append(float(l[5]))
                        self.bubble_sensor_3.append(float(l[6]))
                        self.bubble_sensor_4.append(float(l[7]))
                        self.bubble_sensor_5.append(float(l[8]))
                        self.bubble_sensor_6.append(float(l[9]))
                        self.bag_scale_sample.append(float(l[10]))
                        self.bag_scale_dilution.append(float(l[11]))
                        self.bag_scale_buffer.append(float(l[12]))
                        self.bag_scale_detergent.append(float(l[13]))
                        self.bag_scale_product.append(float(l[14]))
                        self.bag_scale_waste_1.append(float(l[15]))
                        self.bag_scale_waste_2.append(float(l[16]))
                        self.door_sensor.append(int(l[17]))
                        self.cassette_sensor.append(int(l[18]))
                        self.degasser.append(int(l[19]))
                        self.emergency_stop.append(int(l[20]))
                        self.valve_1.append(int(l[21]))
                        self.valve_2.append(int(l[22]))
                        self.valve_3.append(int(l[23]))
                        self.valve_4.append(int(l[24]))
                        self.valve_5.append(int(l[25]))
                        self.valve_6.append(int(l[26]))
                        self.valve_7.append(int(l[27]))
                        self.valve_8.append(int(l[28]))
                        self.valve_9.append(int(l[29]))
                        self.valve_10.append(int(l[30]))
                        self.valve_11.append(int(l[31]))
                        self.valve_12.append(int(l[32]))
                        self.valve_13.append(int(l[33]))
                        self.valve_14.append(int(l[34]))
                        self.pump_1.append(float(l[35]))
                        self.pump_2.append(float(l[36]))
                        self.pump_3.append(float(l[37]))
                        self.pump_4.append(float(l[38]))

    def print_actions(self):
        for t, a in zip(self.action_time, self.action):
            print("%3.1f" % t + "\t" + a)

    def print_experiments(self):
        for t, e in zip(self.experiment_starts, self.experiments):
            print("%3.1f" % t + '\t' + e)

    def plot_bag_scale_sample(self, start=0, stop=999999999999):
        start_index = np.searchsorted(self.time, start)
        stop_index = np.searchsorted(self.time, stop)
        plt.plot(self.time[start_index:stop_index], self.bag_scale_sample[start_index:stop_index], '.')
        plt.xlabel("Time [s]")
        plt.ylabel("Bag scale sample [g]")
        fit = scipy.stats.linregress(self.time[start_index:stop_index], self.bag_scale_sample[start_index:stop_index])
        print("Slope = %3.3f     Y-int = %3.3f" % (fit[0], fit[1]))
        plt.show()

    def mean_bag_scale_sample(self, start=0, stop=99999999999):
        start_index = np.searchsorted(self.time, start)
        stop_index = np.searchsorted(self.time, stop)
        print("Mean bag scale sample = %3.3f" % np.mean(self.bag_scale_sample[start_index:stop_index]))

    def plot_pressures(self, start=0, stop=99999999999):
        start_index = np.searchsorted(self.time, start)
        stop_index = np.searchsorted(self.time, stop)
        plt.plot(self.time[start_index:stop_index], self.pressure_sensor_1[start_index:stop_index], label="Pressure sensor 1")
        plt.plot(self.time[start_index:stop_index], self.pressure_sensor_2[start_index:stop_index], label="Pressure sensor 2")
        plt.xlabel("Time [s]")
        plt.ylabel("Pressure [kPa]")
        plt.legend()
        plt.show()

    def analyze_bags(self):
        out = open(os.path.splitext(self.filename)[0] + " REPORT.csv", 'w')

        # bag averages:
        out.write("Experiment name,Average bag_scale_sample,Average bag_scale_dilution,Average bag_scale_buffer,Average bag_scale_detergent,Average bag_scale_product,Average bag_scale_waste_1,Average bag_scale_waste_2\n")
        for e, start, stop in zip(self.experiments, self.experiment_starts, self.experiment_ends):
            # print('Experiment "%s" from %0.1f to %0.1f' % (e, start, stop))
            out.write(e + ",")
            start_index = np.searchsorted(self.time, start)
            stop_index = np.searchsorted(self.time, stop)
            out.write(str(np.mean(self.bag_scale_sample[start_index:stop_index])) + ",")
            out.write(str(np.mean(self.bag_scale_dilution[start_index:stop_index])) + ",")
            out.write(str(np.mean(self.bag_scale_buffer[start_index:stop_index])) + ",")
            out.write(str(np.mean(self.bag_scale_detergent[start_index:stop_index])) + ",")
            out.write(str(np.mean(self.bag_scale_product[start_index:stop_index])) + ",")
            out.write(str(np.mean(self.bag_scale_waste_1[start_index:stop_index])) + ",")
            out.write(str(np.mean(self.bag_scale_waste_2[start_index:stop_index])) + "\n")

        # bag slopes:
        out.write("Experiment name,Slope bag_scale_sample,Slope bag_scale_dilution,Slope bag_scale_buffer,Slope bag_scale_detergent,Slope bag_scale_product,Slope bag_scale_waste_1,Slope bag_scale_waste_2\n")
        for e, start, stop in zip(self.experiments, self.experiment_starts, self.experiment_ends):
            # print('Experiment "%s" from %0.1f to %0.1f' % (e, start, stop))
            out.write(e + ",")
            start_index = np.searchsorted(self.time, start)
            stop_index = np.searchsorted(self.time, stop)
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_sample[start_index:stop_index])[0]) + ",")
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_dilution[start_index:stop_index])[0]) + ",")
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_buffer[start_index:stop_index])[0]) + ",")
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_detergent[start_index:stop_index])[0]) + ",")
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_product[start_index:stop_index])[0]) + ",")
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_waste_1[start_index:stop_index])[0]) + ",")
            out.write(str(scipy.stats.linregress(self.time[start_index:stop_index],
                                                 self.bag_scale_waste_2[start_index:stop_index])[0]) + "\n")

        out.close()

        # plot bags:
        for e, start, stop in zip(self.experiments, self.experiment_starts, self.experiment_ends):
            start_index = np.searchsorted(self.time, start)
            stop_index = np.searchsorted(self.time, stop)
            plt.subplots_adjust(left=0.10, right=0.98, bottom=0.10, top=0.95,
                                wspace=0.6, hspace=1.0)
            plt.subplot(331)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_sample[start_index:stop_index])
            plt.title("Bag scale sample")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(332)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_dilution[start_index:stop_index])
            plt.title("Bag scale dilution")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(333)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_buffer[start_index:stop_index])
            plt.title("Bag scale buffer")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(334)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_detergent[start_index:stop_index])
            plt.title("Bag scale detergent")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(335)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_product[start_index:stop_index])
            plt.title("Bag scale product")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(336)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_waste_1[start_index:stop_index])
            plt.title("Bag scale waste 1")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(337)
            plt.plot(self.time[start_index:stop_index],
                     self.bag_scale_waste_2[start_index:stop_index])
            plt.title("Bag scale waste 2")
            plt.xlabel("Time [min]")
            plt.ylabel("Mass [g]")
            plt.subplot(338)
            plt.plot(self.time[start_index:stop_index],
                     self.pressure_sensor_1[start_index:stop_index])
            plt.title("Pressure sensor 1")
            plt.xlabel("Time [min]")
            plt.ylabel("Pressure [kPa]")
            plt.subplot(339)
            plt.plot(self.time[start_index:stop_index],
                     self.pressure_sensor_2[start_index:stop_index])
            plt.title("Pressure sensor 2")
            plt.xlabel("Time [min]")
            plt.ylabel("Pressure [kPa]")
            plt.savefig(os.path.splitext(self.filename)[0] + " REPORT.png")


if __name__ == '__main__':
    if len(sys.argv) == 1:
        print("scooper scoops poops.  v0.0.4")
        print("Usage:  scooper poop1.csv poop2.csv poop3.csv ...")
    else:
        for f in sys.argv[1:]:
            print("Scooping %s..." % f)
            r = run(f)
            r.analyze_bags()
        print("Poop has been scooped!")




